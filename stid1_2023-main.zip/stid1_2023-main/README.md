# README

TEST

Ce repository est à disposition des étudiants de STID pour accéder aux contenus du cours de programmation statistique dans le cadre de la première année du BUT STID.
Attention : il faut télécharger les pdf pour avoir accès aux liens.
Liste des ressources : 

* [CM/](./CM/) : support de présentation du module.
* [TD1/](./TD1/) : sujet du TD1 et image du quiz.
* [TP1/](./TP1/) : sujet du TP1 à rendre sur GitHub avant le cours suivant.
* [TD2/](./TD2/) : sujet du TD2.
* [TP2/](./TP2/) : sujet du TP2 à rendre sur GitHub avant le cours suivant.